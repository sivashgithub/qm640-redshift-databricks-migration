# Data access and provenance
Source: https://www.nyc.gov/site/tlc/about/tlc-trip-record-data.page
Mirror/catalog: https://registry.opendata.aws/nyc-tlc-trip-records-pds/

Planned scope: Green Taxi Trip Record files for January, February, and March 2023.
Fill in after download:
- Retrieval date:
- Exact file names:
- File sizes:
- Source schema/version:
- Row count per file:
- Checksums (if feasible):
- Filtering and preprocessing:
- License/terms reviewed:
Do not commit large raw files unless specifically justified and permitted.
