# QM640 Redshift-to-Databricks Migration Capstone

**Project:** Evaluating a Quality-Assured Data Migration Framework from Amazon Redshift to Databricks Lakehouse: A Data Engineering Case Study  
**Student:** Sivashankar Shanmugasundaram  
**Course:** QM640: Data Analytics Capstone  
**Mentor:** Mr. JAINESH GARG

## Status
This is a reproducibility starter repository. Templates must be adapted and run in your approved AWS/Databricks environment. It does not contain measured results or claim that the migration has been executed.

## Research design
- Dataset: NYC TLC Green Taxi Trip Record data, proposed period January–March 2023.
- Official source: https://www.nyc.gov/site/tlc/about/tlc-trip-record-data.page
- AWS Open Data Registry: https://registry.opendata.aws/nyc-tlc-trip-records-pds/
- Flow: Redshift → S3 Parquet → Databricks Bronze → Silver → Gold.
- RQ1: schema/record/aggregate integrity; RQ2: stage/end-to-end migration time; RQ3: equivalent query runtime; RQ4: incremental vs full-load efficiency.

## Repository setup
1. Create a public repository named `qm640-redshift-databricks-migration` in your own GitHub account.
2. Upload this folder, inspect every file, and replace all placeholders.
3. Download the selected TLC files from the official source; record retrieval date, file names, sizes, schema, and row counts in `data/README.md`.
4. Configure AWS and Databricks access using approved IAM/workspace mechanisms. Never commit secrets.
5. Build and validate the Redshift baseline before exporting.
6. Run validation and benchmarks; save raw logs and real screenshots under `evidence/screenshots/`.
7. Replace the GitHub URL placeholder in the synopsis with the actual published repository URL.
8. Verify public access in a private/incognito browser window.

## Data policy
Do not commit large source data by default. Link to official public sources and include only small derived samples when permitted. Do not upload credentials, access keys, tokens, private endpoints, or personal data.

## Important
All SQL and Python files are templates. Confirm actual field names and data types against the downloaded files. Do not report template output as experimental evidence.
